class Employee:
    name = "Viktor"
    surname = "Letniy"
    age = 32
    salary = 12000

    def __init__(self):
        print(self.name, self.surname, self.age, self.salary)

employee = Employee()

