class Employee:
    pass
employee=Employee()
print(employee)
