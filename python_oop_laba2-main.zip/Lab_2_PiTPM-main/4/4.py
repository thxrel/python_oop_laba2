class Employee:
    pass
employee1=Employee()
employee1.name="Кирилл"
employee1.age=17
employee1.salary=21000
employee2=Employee()
employee2.name="Михаил"
employee2.age=19
employee2.salary=23000
print(employee1.name,employee1.age,employee1.salary)
print(employee2.name,employee2.age,employee2.salary)
