class Employee:
    pass
employee=Employee()
employee.name="Кирилл"
employee.age=17
employee.salary=21000
print(employee.name,employee.age,employee.salary)
